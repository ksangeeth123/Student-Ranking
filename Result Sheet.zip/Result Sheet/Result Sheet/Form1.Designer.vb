﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSRS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblStuName = New System.Windows.Forms.Label()
        Me.lblMark1 = New System.Windows.Forms.Label()
        Me.lblMark2 = New System.Windows.Forms.Label()
        Me.lblTM = New System.Windows.Forms.Label()
        Me.lblAve = New System.Windows.Forms.Label()
        Me.lblGrade = New System.Windows.Forms.Label()
        Me.texName = New System.Windows.Forms.TextBox()
        Me.texM1 = New System.Windows.Forms.TextBox()
        Me.texM2 = New System.Windows.Forms.TextBox()
        Me.texTM = New System.Windows.Forms.TextBox()
        Me.texAve = New System.Windows.Forms.TextBox()
        Me.texGrd = New System.Windows.Forms.TextBox()
        Me.btnOk = New System.Windows.Forms.Button()
        Me.btnTO = New System.Windows.Forms.Button()
        Me.btnAve = New System.Windows.Forms.Button()
        Me.btnGrd = New System.Windows.Forms.Button()
        Me.btnClr = New System.Windows.Forms.Button()
        Me.btnExt = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblStuName
        '
        Me.lblStuName.AutoSize = True
        Me.lblStuName.Location = New System.Drawing.Point(0, 22)
        Me.lblStuName.Name = "lblStuName"
        Me.lblStuName.Size = New System.Drawing.Size(143, 26)
        Me.lblStuName.TabIndex = 0
        Me.lblStuName.Text = "Student Name"
        '
        'lblMark1
        '
        Me.lblMark1.AutoSize = True
        Me.lblMark1.Location = New System.Drawing.Point(0, 69)
        Me.lblMark1.Name = "lblMark1"
        Me.lblMark1.Size = New System.Drawing.Size(76, 26)
        Me.lblMark1.TabIndex = 1
        Me.lblMark1.Text = "Mark 1"
        '
        'lblMark2
        '
        Me.lblMark2.AutoSize = True
        Me.lblMark2.Location = New System.Drawing.Point(0, 119)
        Me.lblMark2.Name = "lblMark2"
        Me.lblMark2.Size = New System.Drawing.Size(76, 26)
        Me.lblMark2.TabIndex = 2
        Me.lblMark2.Text = "Mark 2"
        '
        'lblTM
        '
        Me.lblTM.AutoSize = True
        Me.lblTM.Location = New System.Drawing.Point(0, 169)
        Me.lblTM.Name = "lblTM"
        Me.lblTM.Size = New System.Drawing.Size(113, 26)
        Me.lblTM.TabIndex = 3
        Me.lblTM.Text = "Total Mark"
        '
        'lblAve
        '
        Me.lblAve.AutoSize = True
        Me.lblAve.Location = New System.Drawing.Point(0, 222)
        Me.lblAve.Name = "lblAve"
        Me.lblAve.Size = New System.Drawing.Size(86, 26)
        Me.lblAve.TabIndex = 4
        Me.lblAve.Text = "Average"
        '
        'lblGrade
        '
        Me.lblGrade.AutoSize = True
        Me.lblGrade.Location = New System.Drawing.Point(0, 268)
        Me.lblGrade.Name = "lblGrade"
        Me.lblGrade.Size = New System.Drawing.Size(68, 26)
        Me.lblGrade.TabIndex = 5
        Me.lblGrade.Text = "Grade"
        '
        'texName
        '
        Me.texName.Location = New System.Drawing.Point(312, 12)
        Me.texName.Name = "texName"
        Me.texName.Size = New System.Drawing.Size(230, 33)
        Me.texName.TabIndex = 6
        '
        'texM1
        '
        Me.texM1.Location = New System.Drawing.Point(312, 62)
        Me.texM1.Name = "texM1"
        Me.texM1.Size = New System.Drawing.Size(230, 33)
        Me.texM1.TabIndex = 7
        '
        'texM2
        '
        Me.texM2.Location = New System.Drawing.Point(312, 112)
        Me.texM2.Name = "texM2"
        Me.texM2.Size = New System.Drawing.Size(230, 33)
        Me.texM2.TabIndex = 8
        '
        'texTM
        '
        Me.texTM.Location = New System.Drawing.Point(312, 162)
        Me.texTM.Name = "texTM"
        Me.texTM.Size = New System.Drawing.Size(230, 33)
        Me.texTM.TabIndex = 9
        '
        'texAve
        '
        Me.texAve.Location = New System.Drawing.Point(312, 215)
        Me.texAve.Name = "texAve"
        Me.texAve.Size = New System.Drawing.Size(230, 33)
        Me.texAve.TabIndex = 10
        '
        'texGrd
        '
        Me.texGrd.Location = New System.Drawing.Point(312, 261)
        Me.texGrd.Name = "texGrd"
        Me.texGrd.Size = New System.Drawing.Size(230, 33)
        Me.texGrd.TabIndex = 11
        '
        'btnOk
        '
        Me.btnOk.Location = New System.Drawing.Point(26, 409)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.Size = New System.Drawing.Size(95, 35)
        Me.btnOk.TabIndex = 12
        Me.btnOk.Text = "Ok"
        Me.btnOk.UseVisualStyleBackColor = True
        '
        'btnTO
        '
        Me.btnTO.Location = New System.Drawing.Point(127, 409)
        Me.btnTO.Name = "btnTO"
        Me.btnTO.Size = New System.Drawing.Size(97, 35)
        Me.btnTO.TabIndex = 13
        Me.btnTO.Text = "Total"
        Me.btnTO.UseVisualStyleBackColor = True
        '
        'btnAve
        '
        Me.btnAve.Location = New System.Drawing.Point(230, 409)
        Me.btnAve.Name = "btnAve"
        Me.btnAve.Size = New System.Drawing.Size(97, 35)
        Me.btnAve.TabIndex = 14
        Me.btnAve.Text = "Average"
        Me.btnAve.UseVisualStyleBackColor = True
        '
        'btnGrd
        '
        Me.btnGrd.Location = New System.Drawing.Point(333, 409)
        Me.btnGrd.Name = "btnGrd"
        Me.btnGrd.Size = New System.Drawing.Size(97, 35)
        Me.btnGrd.TabIndex = 15
        Me.btnGrd.Text = "Grade"
        Me.btnGrd.UseVisualStyleBackColor = True
        '
        'btnClr
        '
        Me.btnClr.Location = New System.Drawing.Point(445, 409)
        Me.btnClr.Name = "btnClr"
        Me.btnClr.Size = New System.Drawing.Size(97, 35)
        Me.btnClr.TabIndex = 16
        Me.btnClr.Text = "Clear"
        Me.btnClr.UseVisualStyleBackColor = True
        '
        'btnExt
        '
        Me.btnExt.Location = New System.Drawing.Point(230, 459)
        Me.btnExt.Name = "btnExt"
        Me.btnExt.Size = New System.Drawing.Size(97, 35)
        Me.btnExt.TabIndex = 17
        Me.btnExt.Text = "Exit"
        Me.btnExt.UseVisualStyleBackColor = True
        '
        'frmSRS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 26.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Cyan
        Me.ClientSize = New System.Drawing.Size(568, 524)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnExt)
        Me.Controls.Add(Me.btnClr)
        Me.Controls.Add(Me.btnGrd)
        Me.Controls.Add(Me.btnAve)
        Me.Controls.Add(Me.btnTO)
        Me.Controls.Add(Me.btnOk)
        Me.Controls.Add(Me.texGrd)
        Me.Controls.Add(Me.texAve)
        Me.Controls.Add(Me.texTM)
        Me.Controls.Add(Me.texM2)
        Me.Controls.Add(Me.texM1)
        Me.Controls.Add(Me.texName)
        Me.Controls.Add(Me.lblGrade)
        Me.Controls.Add(Me.lblAve)
        Me.Controls.Add(Me.lblTM)
        Me.Controls.Add(Me.lblMark2)
        Me.Controls.Add(Me.lblMark1)
        Me.Controls.Add(Me.lblStuName)
        Me.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(6)
        Me.Name = "frmSRS"
        Me.Text = "Student Result Sheets"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblStuName As System.Windows.Forms.Label
    Friend WithEvents lblMark1 As System.Windows.Forms.Label
    Friend WithEvents lblMark2 As System.Windows.Forms.Label
    Friend WithEvents lblTM As System.Windows.Forms.Label
    Friend WithEvents lblAve As System.Windows.Forms.Label
    Friend WithEvents lblGrade As System.Windows.Forms.Label
    Friend WithEvents texName As System.Windows.Forms.TextBox
    Friend WithEvents texM1 As System.Windows.Forms.TextBox
    Friend WithEvents texM2 As System.Windows.Forms.TextBox
    Friend WithEvents texTM As System.Windows.Forms.TextBox
    Friend WithEvents texAve As System.Windows.Forms.TextBox
    Friend WithEvents texGrd As System.Windows.Forms.TextBox
    Friend WithEvents btnOk As System.Windows.Forms.Button
    Friend WithEvents btnTO As System.Windows.Forms.Button
    Friend WithEvents btnAve As System.Windows.Forms.Button
    Friend WithEvents btnGrd As System.Windows.Forms.Button
    Friend WithEvents btnClr As System.Windows.Forms.Button
    Friend WithEvents btnExt As System.Windows.Forms.Button

End Class
