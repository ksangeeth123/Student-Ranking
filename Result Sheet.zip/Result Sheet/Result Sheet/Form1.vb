﻿Public Class frmSRS
    Dim Stn As String
    Dim M1 As Integer
    Dim M2 As Integer
    Dim TM As Integer
    Dim Avg As Single
    Dim Grd As String

    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        Stn = texName.Text
        M1 = texM1.Text
        M2 = texM2.Text
    End Sub

    Private Sub btnTO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTO.Click
        TM = M1 + M2
        texTM.Text = TM
    End Sub

    Private Sub btnAve_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAve.Click
        Avg = TM / 2
        texAve.Text = Avg
    End Sub

    Private Sub btnGrd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGrd.Click
        If (Avg >= 75) Then
            Grd = "A"
        ElseIf (Avg >= 65) Then
            Grd = "B"
        ElseIf (Avg >= 55) Then
            Grd = "C"
        ElseIf (Avg >= 35) Then
            Grd = "S"
        ElseIf (Avg < 35) Then
            Grd = "F"
        End If
        texGrd.Text = Grd
    End Sub

    Private Sub btnClr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClr.Click
        texName.Text = ""
        texM1.Text = ""
        texM2.Text = ""
        texTM.Text = ""
        texAve.Text = ""
        texGrd.Text = ""
    End Sub

    Private Sub btnExt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExt.Click
        End
    End Sub
End Class
